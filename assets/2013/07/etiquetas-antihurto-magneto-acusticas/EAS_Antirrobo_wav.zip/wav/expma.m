% Media movil exponencial similar a como lo haríamos en perl
function q = expma(p,v)
	q(1) = p(1);
   	for i = 2:size(p);
	   	q(i) = (1-v).*q(i-1)+v.*p(i);
   	end;
	q = q';
end
