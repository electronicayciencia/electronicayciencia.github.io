% Resonador IIR
% http://eceweb1.rutgers.edu/~orfanidi/ece348/lab6.pdf
function out = resiir(in,R)
	SR = 48000;
	F0 = 4100;
	a1 = - 2 * R * cos(2*pi*F0 / SR);	
	a2 = R^2;
	G = (1 - R) * sqrt(1 - 2*R*cos(2*pi*2*F0/SR) + R^2);
	
	out(1) = in(1);
	out(2) = in(2);
   	for i = 3:size(in);
	   	out(i) = G*in(i) - a1*out(i-1) - a2*out(i-2);
   	end;
	out = out';
end
