function [ pctvot, pctpel ] = ratiovotos( V, n )
%RATIOVOTOS Devuelve el porcentaje de votos inferiores a n
%   V es el vector columna de votos.
%   Dado un vector columa n devuelve qu� tanto por ciento de los votos
%   totales suponen los votos inferiores o iguales a n.
%   Opcionalmente devuelve tambi�n qu� porcentaje de pel�culas
%   supone aquellas que tienen n o menos votos.
    pctvot = n;
    pctpel = n;
    sumaV  = sum(V);
    sumaP  = length(V);
    
    for i = 1:length(n)
        v  = V(V<=n(i));
        pv = sum(v) / sumaV;
        pp = length(v) / sumaP;
        
        pctvot(i) = pv;
        pctpel(i) = pp;
    end
end

