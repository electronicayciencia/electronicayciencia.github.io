function [ notamedia ] = notavotos( V, R, n )
%NOTAVOTOS Devuelve la nota media de las pel�culas con m�s de n votos.
%   V es el vector columna con los votos.
%   R es el vector columna de porcentajes ratio10-9-8...1
    notamedia = n;
    mul = 10:-1:1;
    
    % Primero calculamos todas las notas
    % luego restringimos la media a las que nos interesen.
    notas = [V, dot(R, repmat(mul, length(R),1),2) ./ sum(R,2)];
    for i = 1:length(n)
        notamedia(i) = mean(notas(notas(:,1)>=n(i),2));
    end
end

