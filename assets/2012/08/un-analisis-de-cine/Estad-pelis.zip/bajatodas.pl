#!/usr/bin/perl -w

use strict;
use warnings;
use HTML::Entities;

# Descarga la página de todas las películas de Film Affinity.

# En lugar de la descarga al azar, que provoca muchas colisiones
# se prefiere una descarga sistemática.


$| = 1;
my $wget = 'wget -O - -q';

# Leemos el fichero con la base de datos, para saber los ID que ya tenemos.
my $fich_data = "peliculas.dat";
my %tenemos; # para no repetir

open my $fh, "< $fich_data";
while (my $linea = <$fh>) {
	my @campos = split /\|/, $linea;
	$tenemos{$campos[0]}++;
}
close $fh;


# Ahora vamos letra por letra viendo cuántas páginas tiene
my @letras = qw/* 0-9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z/;
for my $letra (@letras) {

	print "$letra... ";
	my $html  = `$wget http://www.filmaffinity.com/es/allfilms_${letra}_1.html`;
	redo if not $html;

	my ($max) = $html =~ m{<b>1</b> de <b>(\d+)</b></td>};
	redo if not $max;
	
	print "$max páginas.\n";

	# Bajamos cada página
	for my $pagina (1..$max) {
		my $html = `$wget 'http://www.filmaffinity.com/es/allfilms_${letra}_${pagina}.html'`;
		next if not $html;

		# Dentro de la página, obtenemos las pelis que hay
		# Pero sólo las que tienen rating, 
		# Para discriminarlas fácilmente hacemos una transformación previa,
		# que consiste en dejar las tablas en una sola linea y buscar que esa linea
		# contenga 'ratings'
		$html =~ s/\n//g;
		$html =~ s/table/\n/g;
		my @ids = $html =~ m{<b><a href="/es/film(\d+).html">.*ratings/\d+\.gif}g;
		next if not @ids;

		# Seleccionamos una de ellas
		# que no haya salido
		for my $id (@ids) {

			next if not $id;
			
			print "\n$letra $pagina/$max $id: ";
			(print "La tenemos" and next) if $tenemos{$id};

			$tenemos{$id}++;

			# Espera de cortesía
			sleep 1;

			# Obtenemos sus datos
			$html        = `$wget http://www.filmaffinity.com/es/film$id.html`;
			next if not $html;

			my ($titulo) = $html =~ m{<title>\s*(.+)\s+- FilmAffinity</title>};
			my ($votos)  = $html =~ m{>\s*([\d\.]+)\s*votos</div>};
			my @pctvotos = $html =~ /rat10=([\d\.]+)&rat9=([\d\.]+)&rat8=([\d\.]+)&rat7=([\d\.]+)&rat6=([\d\.]+)&rat5=([\d\.]+)&rat4=([\d\.]+)&rat3=([\d\.]+)&rat2=([\d\.]+)&rat1=([\d\.]+)/;

			# Si no tiene suficientes votos o hubo un error toma otra
			$titulo and $votos and @pctvotos or print " Error ($titulo) ($id)" and next;

			$votos  =~ s/\.//g;
			$titulo =~ s/\|//g;
			$titulo = decode_entities($titulo);

			print " $votos -> $titulo";

			# Como separador no podemos usar ; porque es probable que aparezca en 
			# algún título
			local $" = '|';

			# Abrimos y cerramos, para sincronizar en el momento
			open my $fh, ">> $fich_data";
				print $fh "$id|$titulo|$votos|@pctvotos\n";
			close $fh;
		}
	}
}

print "\n";

